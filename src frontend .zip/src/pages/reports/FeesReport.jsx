// FeesReport.jsx
import ReportShell from './ReportShell';
export default function FeesReport() {
  return <ReportShell title="Fees Report" endpoint="/reports/fees/summary" columns={[]} />;
}
