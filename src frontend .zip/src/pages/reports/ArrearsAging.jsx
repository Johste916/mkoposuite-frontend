// ArrearsAging.jsx
import ReportShell from './ReportShell';
export default function ArrearsAging() {
  return <ReportShell title="Loan Arrears Aging" endpoint="/reports/arrears-aging" mode="snapshot" columns={[]} />;
}
