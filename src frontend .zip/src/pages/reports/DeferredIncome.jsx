// DeferredIncome.jsx
import ReportShell from './ReportShell';
export default function DeferredIncome() {
  return <ReportShell title="Deferred Income" endpoint="/reports/deferred-income" columns={[]} />;
}
