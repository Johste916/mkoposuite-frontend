// AllEntries.jsx
import ReportShell from './ReportShell';
export default function AllEntries() {
  return <ReportShell title="All Entries" endpoint="/reports/all-entries" columns={[]} />;
}
