// ProRataCollections.jsx
import ReportShell from './ReportShell';
export default function ProRataCollections() {
  return <ReportShell title="Pro-Rata Collections" endpoint="/reports/pro-rata-collections" columns={[]} />;
}
