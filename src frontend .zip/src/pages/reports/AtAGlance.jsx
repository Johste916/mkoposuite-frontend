// AtAGlance.jsx
import ReportShell from './ReportShell';
export default function AtAGlance() {
  return <ReportShell title="At a Glance" endpoint="/reports/at-a-glance" columns={[]} />;
}
