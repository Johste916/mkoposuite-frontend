// MfrsRatios.jsx
import ReportShell from './ReportShell';
export default function MfrsRatios() {
  return <ReportShell title="MFRS Ratios" endpoint="/reports/mfrs" mode="snapshot" columns={[]} />;
}
