import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function SavingsFees(){ return <TypesEditor title="Savings Fees" category="savings-fees" />; }
