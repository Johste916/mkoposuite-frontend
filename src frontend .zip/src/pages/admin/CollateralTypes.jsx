import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function CollateralTypes(){ return <TypesEditor title="Collateral Types" category="collateral-types" />; }
