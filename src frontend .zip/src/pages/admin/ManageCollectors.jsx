import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function ManageCollectors(){ return <TypesEditor title="Manage Collectors" category="manage-collectors" />; }
