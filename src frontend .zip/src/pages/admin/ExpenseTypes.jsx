import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function ExpenseTypes(){ return <TypesEditor title="Expense Types" category="expense-types" />; }
