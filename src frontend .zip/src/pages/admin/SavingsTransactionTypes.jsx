import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function SavingsTransactionTypes(){ return <TypesEditor title="Savings Transaction Types" category="savings-transaction-types" />; }
