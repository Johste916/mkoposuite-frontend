import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function LoanInvestmentProducts(){ return <TypesEditor title="Loan Investment Products" category="loan-investment-products" />; }
