// src/pages/admin/uploads/UploadLoansCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadLoansCSV(){ return <UploadPage title="Upload Loans (CSV)" endpoint="/api/settings/uploads/loans" />; }