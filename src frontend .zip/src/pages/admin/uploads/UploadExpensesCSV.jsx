// src/pages/admin/uploads/UploadExpensesCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadExpensesCSV(){ return <UploadPage title="Upload Expenses (CSV)" endpoint="/api/settings/uploads/expenses" />; }
