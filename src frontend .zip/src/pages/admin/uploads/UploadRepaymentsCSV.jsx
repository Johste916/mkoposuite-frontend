// src/pages/admin/uploads/UploadRepaymentsCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadRepaymentsCSV(){ return <UploadPage title="Upload Repayments (CSV)" endpoint="/api/settings/uploads/repayments" />; }