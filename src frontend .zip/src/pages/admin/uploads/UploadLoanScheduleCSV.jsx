// src/pages/admin/uploads/UploadLoanScheduleCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadLoanScheduleCSV(){ return <UploadPage title="Upload Loan Schedule (CSV)" endpoint="/api/settings/uploads/loan-schedule" />; }
