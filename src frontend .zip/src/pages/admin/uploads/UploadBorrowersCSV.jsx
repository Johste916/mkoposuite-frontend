// src/pages/admin/uploads/UploadBorrowersCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadBorrowersCSV(){ return <UploadPage title="Upload Borrowers (CSV)" endpoint="/api/settings/uploads/borrowers" />; }
