// src/pages/admin/uploads/UploadInterBankTransferCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadInterBankTransferCSV(){ return <UploadPage title="Upload Inter Bank Transfer (CSV)" endpoint="/api/settings/uploads/inter-bank-transfer" />; }