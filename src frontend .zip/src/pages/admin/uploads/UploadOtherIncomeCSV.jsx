/ src/pages/admin/uploads/UploadOtherIncomeCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadOtherIncomeCSV(){ return <UploadPage title="Upload Other Income (CSV)" endpoint="/api/settings/uploads/other-income" />; }
