// src/pages/admin/uploads/UploadSavingsAccountsCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadSavingsAccountsCSV(){ return <UploadPage title="Upload Savings Accounts (CSV)" endpoint="/api/settings/uploads/savings-accounts" />; }