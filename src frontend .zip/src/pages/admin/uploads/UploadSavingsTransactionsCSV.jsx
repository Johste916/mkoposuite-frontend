// src/pages/admin/uploads/UploadSavingsTransactionsCSV.jsx
import React from "react";
import UploadPage from "./UploadPage";
export default function UploadSavingsTransactionsCSV(){ return <UploadPage title="Upload Savings Transactions (CSV)" endpoint="/api/settings/uploads/savings-transactions" />; }


