import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function SavingsProducts(){ return <TypesEditor title="Savings Products" category="savings-products" />; }
