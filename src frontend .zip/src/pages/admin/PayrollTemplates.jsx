import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function PayrollTemplates(){ return <TypesEditor title="Payroll Templates" category="payroll-templates" />; }
