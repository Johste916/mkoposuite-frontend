import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function OtherIncomeTypes(){ return <TypesEditor title="Other Income Types" category="other-income-types" />; }
