import React from "react";
import TypesEditor from "./_shared/TypesEditor";
export default function InvestorFees(){ return <TypesEditor title="Investor Fees" category="investor-fees" />; }
