// src/pages/admin/EmailTemplatesForESignature.jsx
import React from "react";
import TemplatesList from "./_shared/TemplatesList";
export default function EmailTemplatesForESignature(){
  return <TemplatesList title="Email Templates for E-Signature" channel="email" />;
}