import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams, useNavigate, useSearchParams } from "react-router-dom";
import api from "../../api";
import { fmtCurrency as fmtC, fmtTZS, fmtNum, fmtPct, fmtDate } from "../../utils/format";
import { exportCSVFromRows, exportExcelHTMLFromRows, exportPDFPrintFromRows } from "../../utils/exporters";
import Pagination from "../../components/table/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { useToast } from "../../components/common/ToastProvider";

/* ---------- constants ---------- */
const CORE_STATUSES = ["pending", "approved", "rejected", "disbursed", "active", "closed"];
// Only these should ever be sent as ?status= to backend (DB enum-backed)
const BACKEND_ENUM_STATUSES = ["pending", "approved", "rejected", "disbursed", "closed"];

const TITLE_MAP = {
  pending: "Pending Approval",
  approved: "Approved Loans",
  rejected: "Rejected Loans",
  disbursed: "Disbursed Loans",
  active: "Active Loans",
  closed: "Closed Loans",
  // Derived/scoped lists
  due: "Due Loans",
  missed: "Missed Repayments",
  arrears: "Loans in Arrears",
  "no-repayments": "No Repayments",
  "past-maturity": "Past Maturity Loans",
  "principal-outstanding": "Principal Outstanding",
  "1-month-late": "1 Month Late",
  "3-months-late": "3 Months Late",
};

export default function LoanStatusList() {
  const { status } = useParams(); // core status or a derived scope
  const navigate = useNavigate();
  const { success, error } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const [rows, setRows] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);

  // filter refs
  const [products, setProducts] = useState([]);
  const [officers, setOfficers] = useState([]);

  const [q, setQ] = useState(searchParams.get("q") || "");
  const [productId, setProductId] = useState(searchParams.get("productId") || "");
  const [officerId, setOfficerId] = useState(searchParams.get("officerId") || "");
  const [startDate, setStartDate] = useState(searchParams.get("startDate") || ""); // yyyy-mm-dd
  const [endDate, setEndDate] = useState(searchParams.get("endDate") || ""); // yyyy-mm-dd
  const [minAmt, setMinAmt] = useState(searchParams.get("minAmt") || "");
  const [maxAmt, setMaxAmt] = useState(searchParams.get("maxAmt") || "");

  // pagination
  const initialPage = Number(searchParams.get("page") || 1);
  const initialPageSize = Number(searchParams.get("pageSize") || 25);
  const [page, setPage] = useState(Math.max(1, initialPage));
  const [pageSize, setPageSize] = useState([10, 25, 50, 100].includes(initialPageSize) ? initialPageSize : 25);

  // row menu + assign modal state
  const [menuOpenRow, setMenuOpenRow] = useState(null);
  const [assignModal, setAssignModal] = useState({ open: false, loan: null, officerId: "" });

  // confirms
  const [confirm, setConfirm] = useState({
    open: false,
    title: "",
    description: "",
    destructive: false,
    onConfirm: null,
  });

  const title = TITLE_MAP[status] || "Loans";
  const showActions = ["disbursed", "active"].includes(String(status || "").toLowerCase());

  /* ---------- fetch lists for filters (products & loan officers) ---------- */
  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/loan-products");
        const list = Array.isArray(res.data) ? res.data : res.data?.items || [];
        setProducts(list);
      } catch {
        setProducts([]);
      }
      try {
        const r2 = await api.get("/users", { params: { role: "loan_officer", pageSize: 500 } });
        const data = Array.isArray(r2.data) ? r2.data : r2.data?.items || [];
        setOfficers(data);
      } catch {
        setOfficers([]);
      }
    })();
  }, []);

  /* ---------- load data with server-side filters when possible ---------- */
  const load = async (opts = {}) => {
    setLoading(true);
    try {
      const params = { page, pageSize };

      // Only send DB-backed statuses as ?status=
      if (CORE_STATUSES.includes(String(status))) {
        if (BACKEND_ENUM_STATUSES.includes(String(status))) {
          params.status = String(status);
        } else {
          // derived "active" -> hint as scope, or omit to avoid enum errors in DB
          params.scope = String(status);
        }
      } else if (status) {
        params.scope = status; // derived list hint for backend
      }

      // server-side filters if supported
      if (q.trim()) params.q = q.trim();
      if (productId) params.productId = productId;
      if (officerId) params.officerId = officerId;
      if (startDate) params.startDate = startDate;
      if (endDate) params.endDate = endDate;
      if (minAmt) params.minAmount = minAmt;
      if (maxAmt) params.maxAmount = maxAmt;

      const res = await api.get("/loans", { params });
      const data = Array.isArray(res.data)
        ? res.data
        : Array.isArray(res.data?.items)
        ? res.data.items
        : [];
      let total = res.data?.total ?? data.length;

      // Client-side mapping for "active": treat as disbursed (and optionally still owing)
      let dataAdj = data;
      if (String(status).toLowerCase() === "active") {
        dataAdj = data.filter(
          (l) => String(l.status || l.state || "").toLowerCase() === "disbursed"
        );
        total = dataAdj.length;
      }

      setRows(dataAdj);
      setTotalCount(total);
    } catch (e) {
      console.error(e);
      setRows([]);
      setTotalCount(0);
      error("Failed to load loans.");
    } finally {
      setLoading(false);
    }

    if (!opts.skipSyncUrl) {
      const next = new URLSearchParams();
      if (q) next.set("q", q);
      if (productId) next.set("productId", productId);
      if (officerId) next.set("officerId", officerId);
      if (startDate) next.set("startDate", startDate);
      if (endDate) next.set("endDate", endDate);
      if (minAmt) next.set("minAmt", minAmt);
      if (maxAmt) next.set("maxAmt", maxAmt);
      next.set("page", String(page));
      next.set("pageSize", String(pageSize));
      setSearchParams(next);
    }
  };

  useEffect(() => {
    load({ skipSyncUrl: true }); // first paint reads existing URL
    setMenuOpenRow(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, page, pageSize]);

  /* ---------- client-side filtering fallback ---------- */
  const filtered = useMemo(() => {
    const sd = startDate ? new Date(startDate) : null;
    const ed = endDate ? new Date(endDate) : null;

    return rows.filter((l) => {
      // date range (releaseDate/startDate/disbursementDate/createdAt)
      if (sd || ed) {
        const when = l.releaseDate || l.startDate || l.disbursementDate || l.createdAt || null;
        const d = when ? new Date(when) : null;
        if (sd && (!d || d < sd)) return false;
        if (ed && (!d || d > ed)) return false;
      }
      // product
      if (productId && String(l.productId) !== String(productId)) return false;
      // officer
      if (
        officerId &&
        String(l.officerId || l.loanOfficerId) !== String(officerId)
      )
        return false;
      // amount
      const amt = Number(l.amount ?? l.principal ?? 0);
      if (minAmt && !(amt >= Number(minAmt))) return false;
      if (maxAmt && !(amt <= Number(maxAmt))) return false;
      // q against borrower/product/phone/loan #
      const needle = q.trim().toLowerCase();
      if (needle) {
        const borrower = l.Borrower || l.borrower || {};
        const product = l.Product || l.product || {};
        const hay = [
          borrower.name,
          borrower.phone,
          l.borrowerName,
          l.borrowerPhone,
          product.name,
          l.productName,
          l.loanNumber,
          l.id,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [rows, q, productId, officerId, startDate, endDate, minAmt, maxAmt]);

  // slice for client pagination when server doesn't paginate
  const paged = useMemo(() => {
    // If backend provided total > rows.length, assume server-pagination already applied
    if (totalCount > rows.length) return filtered;
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize, rows.length, totalCount]);

  /* ---------- totals ---------- */
  const totals = useMemo(() => {
    let p = 0,
      i = 0,
      f = 0,
      pen = 0,
      t = 0;
    filtered.forEach((l) => {
      const op = Number(l.outstandingPrincipal || 0);
      const oi = Number(l.outstandingInterest || 0);
      const of = Number(l.outstandingFees || 0);
      const ope = Number(l.outstandingPenalty || 0);
      const tot = l.outstanding != null ? Number(l.outstanding) : op + oi + of + ope;
      p += op;
      i += oi;
      f += of;
      pen += ope;
      t += tot;
    });
    return { p, i, f, pen, t };
  }, [filtered]);

  /* ---------- export helpers ---------- */
  const buildExportRows = () =>
    filtered.map((l) => {
      const borrower = l.Borrower || l.borrower || {};
      const product = l.Product || l.product || {};
      const officer = l.officer || {};
      const currency = l.currency || "TZS";
      const date = l.releaseDate || l.startDate || l.disbursementDate || l.createdAt || null;

      const op = l.outstandingPrincipal ?? null;
      const oi = l.outstandingInterest ?? null;
      const of = l.outstandingFees ?? null;
      const ope = l.outstandingPenalty ?? null;
      const totalOutstanding =
        l.outstanding != null
          ? l.outstanding
          : [op, oi, of, ope].every((x) => x == null)
          ? null
          : Number(op || 0) + Number(oi || 0) + Number(of || 0) + Number(ope || 0);

      const annualRate =
        l.interestRateAnnual != null
          ? l.interestRateAnnual
          : l.interestRate != null
          ? l.interestRate
          : null;
      const termMonths = l.termMonths ?? l.durationMonths ?? null;

      return {
        Date: fmtDate(date),
        "Borrower Name": borrower.name || l.borrowerName || "",
        "Phone Number": borrower.phone || l.borrowerPhone || "",
        "Loan Product": product.name || l.productName || "",
        "Principal Amount": `${currency} ${Number(l.amount ?? l.principal ?? 0)}`,
        "Interest Amount": `${currency} ${Number(l.interestAmount ?? 0)}`,
        "Outstanding Principal": `${currency} ${Number(op ?? 0)}`,
        "Outstanding Interest": `${currency} ${Number(oi ?? 0)}`,
        "Outstanding Fees": `${currency} ${Number(of ?? 0)}`,
        "Outstanding Penalty": `${currency} ${Number(ope ?? 0)}`,
        "Total Outstanding": `${currency} ${Number(totalOutstanding ?? 0)}`,
        "Interest Rate/Year (%)": annualRate ?? "",
        "Loan Duration (Months)": termMonths ?? "",
        "Loan Officer": l.officerName || officer.name || "",
        Status: l.status || "",
      };
    });

  const exportCSV = () =>
    exportCSVFromRows(buildExportRows(), (TITLE_MAP[status] || "loans").toLowerCase().replace(/\s+/g, "-"));

  const exportExcel = () =>
    exportExcelHTMLFromRows(buildExportRows(), (TITLE_MAP[status] || "loans").toLowerCase().replace(/\s+/g, "-"));

  const exportPDF = () => exportPDFPrintFromRows(buildExportRows(), TITLE_MAP[status] || "Loans");

  /* ---------- row actions ---------- */
  const viewLoan = (id) => navigate(`/loans/${id}`);
  const editLoan = (id) => navigate(`/loans/${id}?edit=1`);
  const redisburse = (id) =>
    setConfirm({
      open: true,
      destructive: false,
      title: "Re-disburse this loan?",
      description:
        "You will be taken to the disbursement screen to create a new disbursement tied to this loan.",
      onConfirm: () => navigate(`/loans/${id}/disburse`),
    });
  const recordRepayment = (id) => navigate(`/repayments/new?loanId=${id}`);
  const reschedule = (id) =>
    setConfirm({
      open: true,
      destructive: false,
      title: "Reschedule repayments?",
      description: "Open the schedule tool to recompute the repayment plan for this loan.",
      onConfirm: () => navigate(`/loans/schedule?loanId=${id}`),
    });

  const downloadSchedule = async (row) => {
    try {
      const res = await api.get(`/loans/${row.id}/schedule`);
      const data = Array.isArray(res.data) ? res.data : [];
      const columns = [
        { label: "#", value: (_r, i) => i + 1 },
        { label: "Due Date", value: (r) => (r.dueDate ? new Date(r.dueDate).toISOString().slice(0, 10) : "") },
        { label: "Principal", value: (r) => r.principal ?? 0 },
        { label: "Interest", value: (r) => r.interest ?? 0 },
        { label: "Penalty", value: (r) => r.penalty ?? 0 },
        {
          label: "Total",
          value: (r) => r.total ?? (Number(r.principal || 0) + Number(r.interest || 0) + Number(r.penalty || 0)),
        },
        { label: "Balance", value: (r) => r.balance ?? "" },
      ];
      const head = columns.map((c) => `"${c.label.replace(/"/g, '""')}"`).join(",");
      const body = data
        .map((row, i) =>
          columns.map((c) => `"${String(c.value(row, i) ?? "").replace(/"/g, '""')}"`).join(",")
        )
        .join("\n");
      const csv = `${head}\n${body}`;
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `loan_${row.id}_schedule.csv`;
      a.click();
      success("Schedule downloaded.");
    } catch (e) {
      console.error(e);
      error("Couldn't download schedule.");
    }
  };

  const openAssignOfficer = (loan) =>
    setAssignModal({ open: true, loan, officerId: loan?.loanOfficerId || loan?.officerId || "" });

  const submitAssignOfficer = async () => {
    const { loan, officerId } = assignModal;
    if (!loan || !officerId) return;
    try {
      await api
        .patch(`/loans/${loan.id}/assign-officer`, { userId: officerId })
        .catch(() => api.patch(`/loans/${loan.id}`, { loanOfficerId: officerId }));
      // refresh local row
      setRows((prev) =>
        prev.map((l) =>
          l.id === loan.id
            ? {
                ...l,
                loanOfficerId: officerId,
                officerId: officerId,
                officerName:
                  officers.find((o) => String(o.id) === String(officerId))?.name || l.officerName,
              }
            : l
        )
      );
      setAssignModal({ open: false, loan: null, officerId: "" });
      success("Loan officer assigned.");
    } catch (e) {
      console.error(e);
      error("Failed to assign officer.");
    }
  };

  /* ---------- render ---------- */
  const baseHeadCount = 15; // number of data columns before Action
  const headCount = baseHeadCount + (showActions ? 1 : 0);

  const dropdownRef = useRef(null);
  useEffect(() => {
    const onDoc = (e) => {
      if (!dropdownRef.current) return;
      if (!dropdownRef.current.contains(e.target)) setMenuOpenRow(null);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  return (
    <div className="p-4 space-y-4">
      {/* header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <div className="text-sm text-gray-600">
            Total: {fmtNum(totalCount)}{" "}
            <span className="mx-2 text-gray-400">•</span>
            <Link to="/loans" className="text-indigo-600 underline">
              All Loans
            </Link>
          </div>
        </div>

        {/* export buttons */}
        <div className="flex flex-wrap gap-2">
          <button onClick={exportCSV} className="px-3 py-2 rounded border hover:bg-gray-50">
            Export CSV
          </button>
          <button onClick={exportExcel} className="px-3 py-2 rounded border hover:bg-gray-50">
            Export Excel
          </button>
          <button onClick={exportPDF} className="px-3 py-2 rounded border hover:bg-gray-50">
            Export PDF
          </button>
        </div>
      </div>

      {/* filters */}
      <div className="bg-white rounded shadow border p-3">
        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="md:col-span-2">
            <label className="text-xs text-gray-600">
              Search (borrower / phone / product / loan #)
            </label>
            <input
              className="w-full border rounded px-3 py-2"
              placeholder="e.g. Jane, 0712…, Business Loan"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs text-gray-600">Product</label>
            <select
              className="w-full border rounded px-3 py-2"
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
            >
              <option value="">All</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                  {p.code ? ` (${p.code})` : ""}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs text-gray-600">Loan Officer</label>
            <select
              className="w-full border rounded px-3 py-2"
              value={officerId}
              onChange={(e) => setOfficerId(e.target.value)}
            >
              <option value="">All</option>
              {officers.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name || o.email}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs text-gray-600">From Date</label>
            <input
              type="date"
              className="w-full border rounded px-3 py-2"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs text-gray-600">To Date</label>
            <input
              type="date"
              className="w-full border rounded px-3 py-2"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs text-gray-600">Min Amount</label>
            <input
              type="number"
              className="w-full border rounded px-3 py-2"
              value={minAmt}
              onChange={(e) => setMinAmt(e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs text-gray-600">Max Amount</label>
            <input
              type="number"
              className="w-full border rounded px-3 py-2"
              value={maxAmt}
              onChange={(e) => setMaxAmt(e.target.value)}
            />
          </div>
        </div>

        <div className="mt-3 flex gap-2">
          <button
            onClick={() => {
              setPage(1);
              load();
            }}
            className="px-3 py-2 rounded bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Apply Filters
          </button>
          <button
            onClick={() => {
              setQ("");
              setProductId("");
              setOfficerId("");
              setStartDate("");
              setEndDate("");
              setMinAmt("");
              setMaxAmt("");
              setPage(1);
              setSearchParams(new URLSearchParams());
              setTimeout(() => load({ skipSyncUrl: true }), 0);
            }}
            className="px-3 py-2 rounded border hover:bg-gray-50"
          >
            Reset
          </button>
        </div>
      </div>

      {/* table */}
      <div className="bg-white rounded shadow border overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-gray-700">
            <tr className="[&>th]:px-2 [&>th]:py-2 [&>th]:border">
              <th>Date</th>
              <th>Borrower Name</th>
              <th>Phone Number</th>
              <th>Loan Product</th>
              <th>Principal Amount</th>
              <th>Interest Amount</th>
              <th>Outstanding Principal</th>
              <th>Outstanding Interest</th>
              <th>Outstanding Fees</th>
              <th>Outstanding Penalty</th>
              <th>Total Outstanding</th>
              <th>Interest Rate/Year (%)</th>
              <th>Loan Duration (Months)</th>
              <th>Loan Officer</th>
              <th>Status</th>
              {showActions && <th>Action</th>}
            </tr>
          </thead>

        <tbody ref={dropdownRef}>
            {loading ? (
              <tr>
                <td colSpan={15 + (showActions ? 1 : 0)} className="p-6 text-center text-gray-500">
                  Loading…
                </td>
              </tr>
            ) : paged.length === 0 ? (
              <tr>
                <td colSpan={15 + (showActions ? 1 : 0)} className="p-6 text-center text-gray-500">
                  No loans found.
                </td>
              </tr>
            ) : (
              paged.map((l) => {
                const borrower = l.Borrower || l.borrower || {};
                const product = l.Product || l.product || {};
                const officer = l.officer || {};
                const currency = l.currency || "TZS";

                const date =
                  l.releaseDate || l.startDate || l.createdAt || l.disbursementDate || null;

                const op = l.outstandingPrincipal ?? null;
                const oi = l.outstandingInterest ?? null;
                const of = l.outstandingFees ?? null;
                const ope = l.outstandingPenalty ?? null;
                const totalOutstanding =
                  l.outstanding != null
                    ? l.outstanding
                    : [op, oi, of, ope].every((x) => x == null)
                    ? null
                    : Number(op || 0) + Number(oi || 0) + Number(of || 0) + Number(ope || 0);

                const annualRate =
                  l.interestRateAnnual != null
                    ? l.interestRateAnnual
                    : l.interestRate != null
                    ? l.interestRate
                    : null;

                const termMonths = l.termMonths ?? l.durationMonths ?? null;

                return (
                  <tr key={l.id} className="[&>td]:px-2 [&>td]:py-2 [&>td]:border hover:bg-gray-50">
                    <td>{fmtDate(date)}</td>
                    <td>
                      {borrower.id ? (
                        <Link to={`/borrowers/${borrower.id}`} className="text-indigo-700 hover:underline">
                          {borrower.name || l.borrowerName || "—"}
                        </Link>
                      ) : (
                        borrower.name || l.borrowerName || "—"
                      )}
                    </td>
                    <td>{borrower.phone || l.borrowerPhone || "—"}</td>
                    <td>{product.name || l.productName || "—"}</td>
                    <td>{fmtC(l.amount ?? l.principal, currency)}</td>
                    <td>{fmtC(l.interestAmount, currency)}</td>
                    <td>{fmtTZS(op, currency)}</td>
                    <td>{fmtTZS(oi, currency)}</td>
                    <td>{fmtTZS(of, currency)}</td>
                    <td>{fmtTZS(ope, currency)}</td>
                    <td>{fmtTZS(totalOutstanding, currency)}</td>
                    <td>{fmtPct(annualRate)}</td>
                    <td>{fmtNum(termMonths)}</td>
                    <td>{l.officerName || officer.name || "—"}</td>
                    <td>{l.status || "—"}</td>

                    {showActions && (
                      <td className="whitespace-nowrap">
                        <div className="relative inline-block">
                          <button
                            className="px-2 py-1 rounded border hover:bg-gray-50"
                            onClick={() => setMenuOpenRow((r) => (r === l.id ? null : l.id))}
                          >
                            Actions ▾
                          </button>
                          {menuOpenRow === l.id && (
                            <div className="absolute right-0 mt-1 w-56 bg-white border rounded shadow-lg z-10">
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  viewLoan(l.id);
                                }}
                              >
                                View (details & repayments)
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  editLoan(l.id);
                                }}
                              >
                                Edit
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  recordRepayment(l.id);
                                }}
                              >
                                Record Repayment
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={async () => {
                                  setMenuOpenRow(null);
                                  await downloadSchedule(l);
                                }}
                              >
                                Download Schedule (CSV)
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  reschedule(l.id);
                                }}
                              >
                                Reschedule Repayments
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  redisburse(l.id);
                                }}
                              >
                                Re-disburse
                              </button>
                              <button
                                className="w-full text-left px-3 py-2 hover:bg-gray-50"
                                onClick={() => {
                                  setMenuOpenRow(null);
                                  openAssignOfficer(l);
                                }}
                              >
                                Assign Loan Officer
                              </button>
                            </div>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>

          {!loading && filtered.length > 0 && (
            <tfoot>
              <tr className="bg-gray-50 font-semibold [&>td]:px-2 [&>td]:py-2 [&>td]:border">
                <td colSpan={6} className="text-right">
                  Totals:
                </td>
                <td>{fmtTZS(totals.p)}</td>
                <td>{fmtTZS(totals.i)}</td>
                <td>{fmtTZS(totals.f)}</td>
                <td>{fmtTZS(totals.pen)}</td>
                <td>{fmtTZS(totals.t)}</td>
                <td colSpan={4 + (showActions ? 1 : 0)}></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {/* pagination */}
      <Pagination
        page={page}
        pageSize={pageSize}
        total={totalCount || filtered.length}
        onPageChange={(p) => setPage(p)}
        onPageSizeChange={(s) => {
          setPageSize(s);
          setPage(1);
        }}
      />

      {/* Assign officer modal */}
      {assignModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-lg font-semibold">Assign Loan Officer</h4>
              <button
                onClick={() => setAssignModal({ open: false, loan: null, officerId: "" })}
                className="text-gray-500 hover:text-gray-700"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="text-sm text-gray-700">
                Loan:{" "}
                <span className="font-medium">
                  {assignModal.loan?.Borrower?.name ||
                    assignModal.loan?.borrowerName ||
                    `#${assignModal.loan?.id}`}
                </span>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Officer</label>
                <select
                  className="w-full border rounded px-3 py-2"
                  value={assignModal.officerId}
                  onChange={(e) =>
                    setAssignModal((s) => ({ ...s, officerId: e.target.value }))
                  }
                >
                  <option value="">Select officer…</option>
                  {officers.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name || o.fullName || o.email || `User ${o.id}`}
                    </option>
                  ))}
                </select>
                {!officers.length && (
                  <p className="text-xs text-amber-600 mt-1">
                    No officers found. Ensure users with role “loan_officer” exist.
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setAssignModal({ open: false, loan: null, officerId: "" })}
                className="px-3 py-2 rounded border"
              >
                Cancel
              </button>
              <button
                onClick={submitAssignOfficer}
                disabled={!assignModal.officerId}
                className="px-4 py-2 rounded bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-60"
              >
                Assign
              </button>
            </div>
          </div>
        </div>
      )}

      {/* confirmations */}
      <ConfirmDialog
        open={confirm.open}
        title={confirm.title}
        description={confirm.description}
        destructive={confirm.destructive}
        onConfirm={confirm.onConfirm}
        onClose={() => setConfirm((c) => ({ ...c, open: false }))}
      />
    </div>
  );
}
