import React from 'react';

const Bank = () => {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Bank Transactions</h2>
      <p>This section will help manage bank deposits, withdrawals, and reconciliations.</p>
    </div>
  );
};

export default Bank;
