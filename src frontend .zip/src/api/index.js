import axios from "axios";

// Prefer env var, fall back to origin + /api (works on Render/Netlify proxy setups)
const baseURL =
  import.meta.env.VITE_API_BASE_URL?.replace(/\/+$/, "") ||
  `${window.location.origin}/api`;

const api = axios.create({
  baseURL,
  withCredentials: false, // set true only if you use cookie-based auth
});

const TOKEN_KEYS = ["token", "authToken", "accessToken", "jwt"];

api.interceptors.request.use((config) => {
  let token = null;
  for (const k of TOKEN_KEYS) {
    token = localStorage.getItem(k) || sessionStorage.getItem(k);
    if (token) break;
  }
  if (token) config.headers.Authorization = `Bearer ${token.replace(/^Bearer /i, "")}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const msg =
      err?.response?.data?.error ||
      err?.response?.data?.message ||
      err?.message ||
      "Request failed";
    console.error("API error:", msg, err?.response || err);
    return Promise.reject(err);
  }
);

export default api;
